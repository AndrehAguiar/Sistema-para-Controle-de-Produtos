<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_Controle_Prod = "localhost";
$database_Controle_Prod = "controller_products";
$username_Controle_Prod = "Administrador";
$password_Controle_Prod = "(LocalAdmin)159357";
$Controle_Prod = mysql_pconnect($hostname_Controle_Prod, $username_Controle_Prod, $password_Controle_Prod) or trigger_error(mysql_error(),E_USER_ERROR); 
?>