<?php require_once('../Connections/Controle_Prod.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "../index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "../index.php?acesso=erro";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO categoria (descricao, data_cadastro, usuario_id) VALUES (%s, %s, %s)",
                       GetSQLValueString($_POST['descricao'], "text"),
                       GetSQLValueString($_POST['data_cadastro'], "text"),
                       GetSQLValueString($_POST['usuario_id'], "int"));

  mysql_select_db($database_Controle_Prod, $Controle_Prod);
  $Result1 = mysql_query($insertSQL, $Controle_Prod) or die(mysql_error());
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form2")) {
  $updateSQL = sprintf("UPDATE categoria SET descricao=%s, usuario_id=%s WHERE id=%s",
                       GetSQLValueString($_POST['descricao2'], "text"),
                       GetSQLValueString($_POST['usuario_id'], "int"),
                       GetSQLValueString($_POST['id'], "int"));

  mysql_select_db($database_Controle_Prod, $Controle_Prod);
  $Result1 = mysql_query($updateSQL, $Controle_Prod) or die(mysql_error());

  $updateGoTo = "categorias.php?atualiza=sucesso";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

if ((isset($_POST['id'])) && ($_POST['id'] != "") && (isset($_GET['delete']))) {
  $deleteSQL = sprintf("DELETE FROM categoria WHERE id=%s",
                       GetSQLValueString($_POST['id'], "int"));

  mysql_select_db($database_Controle_Prod, $Controle_Prod);
  $Result1 = mysql_query($deleteSQL, $Controle_Prod) or die(mysql_error());

  $deleteGoTo = "categorias.php?excluido=sucesso";
  if (isset($_SERVER['QUERY_STRING'])) {
    $deleteGoTo .= (strpos($deleteGoTo, '?')) ? "&" : "?";
    $deleteGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $deleteGoTo));
}

$maxRows_RsCategorias = 10;
$pageNum_RsCategorias = 0;
if (isset($_GET['pageNum_RsCategorias'])) {
  $pageNum_RsCategorias = $_GET['pageNum_RsCategorias'];
}
$startRow_RsCategorias = $pageNum_RsCategorias * $maxRows_RsCategorias;

mysql_select_db($database_Controle_Prod, $Controle_Prod);
$query_RsCategorias = "SELECT * FROM categoria ORDER BY id ASC";
$query_limit_RsCategorias = sprintf("%s LIMIT %d, %d", $query_RsCategorias, $startRow_RsCategorias, $maxRows_RsCategorias);
$RsCategorias = mysql_query($query_limit_RsCategorias, $Controle_Prod) or die(mysql_error());
$row_RsCategorias = mysql_fetch_assoc($RsCategorias);

if (isset($_GET['totalRows_RsCategorias'])) {
  $totalRows_RsCategorias = $_GET['totalRows_RsCategorias'];
} else {
  $all_RsCategorias = mysql_query($query_RsCategorias);
  $totalRows_RsCategorias = mysql_num_rows($all_RsCategorias);
}
$totalPages_RsCategorias = ceil($totalRows_RsCategorias/$maxRows_RsCategorias)-1;

$colname_RsAtualizaCateg = "-1";
if (isset($_GET['atualiza'])) {
  $colname_RsAtualizaCateg = $_GET['atualiza'];
}
mysql_select_db($database_Controle_Prod, $Controle_Prod);
$query_RsAtualizaCateg = sprintf("SELECT * FROM categoria WHERE id = %s ORDER BY id ASC", GetSQLValueString($colname_RsAtualizaCateg, "int"));
$RsAtualizaCateg = mysql_query($query_RsAtualizaCateg, $Controle_Prod) or die(mysql_error());
$row_RsAtualizaCateg = mysql_fetch_assoc($RsAtualizaCateg);
$totalRows_RsAtualizaCateg = mysql_num_rows($RsAtualizaCateg);

$colname_RsExcluiCateg = "-1";
if (isset($_GET['exclui'])) {
  $colname_RsExcluiCateg = $_GET['exclui'];
}
mysql_select_db($database_Controle_Prod, $Controle_Prod);
$query_RsExcluiCateg = sprintf("SELECT * FROM categoria WHERE id = %s", GetSQLValueString($colname_RsExcluiCateg, "int"));
$RsExcluiCateg = mysql_query($query_RsExcluiCateg, $Controle_Prod) or die(mysql_error());
$row_RsExcluiCateg = mysql_fetch_assoc($RsExcluiCateg);
$totalRows_RsExcluiCateg = mysql_num_rows($RsExcluiCateg);

$queryString_RsCategorias = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_RsCategorias") == false && 
        stristr($param, "totalRows_RsCategorias") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_RsCategorias = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_RsCategorias = sprintf("&totalRows_RsCategorias=%d%s", $totalRows_RsCategorias, $queryString_RsCategorias);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Administra Categorias</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css" />

<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<style type="text/css">
		#sessao{		
		text-align: right;
		position:relative;
		float: right;
		clear:both;
		margin:15px;
	}
	#lista{
		width:75%;
		position:relative;
		margin:0 auto;
		clear:both;
		z-index:5;
	}
	#geral #conteudo #lista #ls_titulo {
		text-align: center;
	}
	#geral #conteudo #lista #listaCategoria {
		text-align: center;
	}
	#geral #conteudo #lista #listaCategoria {
		font-weight: bold;
	}
	#conteudo #listaCategoria table th {
		border-bottom:#999 1px solid;
	}
	#conteudo #listaCategoria table td {
	border-bottom: #333 1px solid;
	border-left: #666 1px solid;
	font-weight: normal;
	}
	#conteudo #listaCategoria table td a{
		text-decoration:none;
		color:#900;
	}
	#conteudo #listaCategoria table td a:hover{
		text-decoration:none;
		color: #666;
	}
	#geral #conteudo #lista #cadastraCateg {
		text-align: center;
	}
	#geral #conteudo #lista #cadastraCateg {
		font-weight: bold;
	}
	#geral #conteudo #lista #cadastraCateg #form1 table {
		text-align: left;
	}
	#listaCategoria {
	width: 100%;
	position: absolute;
	margin: 0 auto;
	top: 130px;
	height: auto;
	padding: 10px;
	background-color: #FFFFFF;
	box-shadow: #999 2px 2px 5px 5px;
	z-index: 1;
	visibility: visible;
	}
	#cadastraCateg {
	width: 100%;
	position: absolute;
	margin: 0 auto;
	top: 130px;
	height: auto;
	padding: 10px;
	z-index: 2;
	background-color: #FFFFFF;
	box-shadow: #999 2px 2px 5px 5px;
	visibility: hidden;
	}
#atualizaCateg {
	width: 100%;
	position: absolute;
	margin: 0 auto;
	top: 130px;
	height: auto;
	padding: 10px;
	z-index: 3;
	background-color: #FFFFFF;
	box-shadow: #999 2px 2px 5px 5px;
	visibility: hidden;
}
#geral #conteudo #lista #atualizaCateg {
	text-align: center;
}
#geral #conteudo #lista #atualizaCateg {
	font-weight: bold;
	text-align: left;
}
#excluiCateg {
	width: 100%;
	position: absolute;
	margin: 0 auto;
	top: 130px;
	height: auto;
	padding: 10px;
	z-index: 3;
	background-color: #FFFFFF;
	box-shadow: #999 2px 2px 5px 5px;
	visibility: hidden;
}
#geral #conteudo #lista #excluiCateg strong {
	text-align: center;
	font-weight: bold;
}
#geral #conteudo #lista #excluiCateg {
	text-align: center;
}
#geral #conteudo #lista #excluiCateg {
	font-weight: bold;
}
#geral #conteudo #lista #atualizaCateg {
	text-align: left;
}
#geral #conteudo #lista #atualizaCateg {
	text-align: center;
}
#geral #conteudo #lista #atualizaCateg #form2 table {
	text-align: left;
}
</style>
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script type="text/javascript">
function MM_showHideLayers() { //v9.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) 
  with (document) if (getElementById && ((obj=getElementById(args[i]))!=null)) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
    obj.visibility=v; }
}
function MM_goToURL() { //v3.0
  var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
  for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
}
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
</script>
</head>

<body>
<div id="geral">
      <div id="topo">
            <span id="pg_titulo">
                    <strong>Administrar Categorias</strong><br />
            </span>
    <div style="position: absolute; clear:both; float:left; left:15px; top:33px; vertical-align: text-top; ">
    <img src="../imagens/logo.jpg" width="90" height="90" style="alignment-baseline:central;" />
    
    <span style="width: 309px; text-align: left; font-size: 14px; position: absolute; clear: both; top: 3px; left: 104px; line-height: 130%; height: 97px;"> <b>Test Programming Language</b><br />

T (31) 3515-0800, F (31) 3516-0801
comercial@freebsdbrasil.com.br
http://www.freebsdbrasil.com.br
      <br />
Av Getulio Vargas, 54 - 3 andar, Belo Horizonte MG</span></div>
   	
                    
                    <span id="sessao">
                        Ol&aacute; Sr(a).<b>
                        <?php echo $_SESSION['MM_lname']; ?></b>, <b><?php echo $_SESSION['MM_fname']; ?>(a)</b>!<br />
Seja bem vindo(a)!<br />
<a href="<?php echo $logoutAction ?>"><input name="logout" type="button" value="Sair" /></a>
</div>
<hr />
<div id="conteudo">
    <div id="lista">
      <span id="ls_titulo">
                  <h2>Op&ccedil;&otilde;es de Administrador</h2>

      <span>
                      
      <font size="+1">
      <div id="ls_menu">
                                  <a href="index.php">Adiministrar Usu&aacute;rios</a> &#124;
                                  <a href="produtos.php">Adiministrar Produtos</a> &#124;
                                  <a href="categorias.php">Adiministrar Categorias</a>
          </div>
                      </font>
                      
                     
    <hr style="margin-bottom:-15; margin-top:0px;"/>
      </span><br />
      </span>
      <span id="lnk_cadastro">
      
                        
      	<div  style="position: absolute;"> 
                        Categoria: <a href="#" onclick="MM_showHideLayers('listaCategoria','','show','cadastraCateg','','hide','atualizaCateg','','hide','excluiCateg','','hide')"><strong>Visualizar</strong></a> &#124 
                        
                        <a href="#" onclick="MM_showHideLayers('listaCategoria','','hide','cadastraCateg','','show','atualizaCateg','','hide','excluiCateg','','hide')"><strong>Novo</strong></a>
                        
                &#124;       
      
          <span  style="position: relative; display:inline-block; clear:both;">
          </span>
          
          <span  style="position: relative; display:inline-block; clear:both;">
<form action="categorias.php?atualiza=<?php echo $row_RsCategorias['id']; ?>#" name="form6" target="_self" id="form6"  style="position: relative; visibility: visible;"> 
                  
          <select name="editacateg" id="editacateg" onchange="MM_goToURL('parent','categorias.php?atualiza=<?php echo $row_RsCategorias['id']; ?>#');return document.MM_returnValue" onmouseout="MM_jumpMenu('parent',this,0)">
            <?php
    do {  
    ?>
            <option value="?atualiza=<?php echo $row_RsCategorias['id']; ?>#" selected="selected"<?php if (!(strcmp($row_RsCategorias['id'], $row_RsCategorias['id']))) {echo "selected=\"selected\"";} ?>><?php echo $row_RsCategorias['descricao']?></option>
            <?php
    } while ($row_RsCategorias = mysql_fetch_assoc($RsCategorias));
      $rows = mysql_num_rows($RsCategorias);
      if($rows > 0) {
          mysql_data_seek($RsCategorias, 0);
          $row_RsCategorias = mysql_fetch_assoc($RsCategorias);
      }
    ?>
          </select>                 
             
          
          <a href="#" onclick="MM_showHideLayers('listaCategoria','','hide','cadastraProd','','hide','atualizaCateg','','show','excluiCateg','','hide')"><strong >Editar </strong></a>
          </form>
      
          </span>
      &#124 
      <span  style="position: relative; display:inline-block;">
          
          
        <form action="categorias.php?deleta=<?php echo $row_RsCategorias['id']; ?>#" name="form7" target="_self" id="form7"  style="position: relative;"> 
                  
           <select name="excluicateg" id="excluicateg" onchange="MM_goToURL('parent','categorias.php?exclui=<?php echo $row_RsCategorias['id']; ?>#');return document.MM_returnValue" onmouseout="MM_jumpMenu('parent',this,0)">
             <?php
    do {  
    ?>
             <option value="?exclui=<?php echo $row_RsCategorias['id']; ?>#" selected="selected"<?php if (!(strcmp($row_RsCategorias['id'], $row_RsCategorias['id']))) {echo "selected=\"selected\"";} ?>><?php echo $row_RsCategorias['descricao']?></option>
             <?php
    } while ($row_RsCategorias = mysql_fetch_assoc($RsCategorias));
      $rows = mysql_num_rows($RsCategorias);
      if($rows > 0) {
          mysql_data_seek($RsCategorias, 0);
          $row_RsCategorias = mysql_fetch_assoc($RsCategorias);
      }
    ?>
           </select>
          
          
          <a href="#" onclick="MM_showHideLayers('listaCategoria','','hide','cadastraCateg','','hide','atualizaCateg','','hide','excluiCateg','','show')"><strong>Excluir </strong></a>                 
             
          </form>
      
      </span>
      
      
      </div>
      
      <div id="listaCategoria">
               		<h3>Categorias cadastradas</h3>
       	<hr style="margin-bottom:2px;"/>
                    <table width="100%" border="0" align="center" cellpadding="3" cellspacing="3">
              <tr>
                <th>C&oacute;digo</th>
                <th>Descri&ccedil;&atilde;o</th>
                <th>Cadastrado</th>
                <th>C&oacute;d. do Usu&aacute;rio</th>
                <th>&nbsp;</th>
              </tr>
              <?php do { ?>
                <tr valign="middle">
                  <td><?php echo $row_RsCategorias['id']; ?></td>
                  <td align="left"><?php echo $row_RsCategorias['descricao']; ?></td>
                  <td><?php echo $row_RsCategorias['data_cadastro']; ?></td>
                  <td colspan="2" style="border-right: #333 1px solid;"><?php echo $row_RsCategorias['usuario_id']; ?></td>
              </tr>
                <?php } while ($row_RsCategorias = mysql_fetch_assoc($RsCategorias)); ?>
                </table>
                    <?php if ($pageNum_RsCategorias > 0) { // Show if not first page ?>
  <a href="<?php printf("%s?pageNum_RsCategorias=%d%s", $currentPage, 0, $queryString_RsCategorias); ?>" style="text-decoration:none; color:#900;"> &lt;&lt; </a> <a href="<?php printf("%s?pageNum_RsCategorias=%d%s", $currentPage, max(0, $pageNum_RsCategorias - 1), $queryString_RsCategorias); ?>" style="text-decoration:none; color:#900;"> &lt; </a>
  
	  &#124;
      
  <?php } // Show if not first page ?>
<?php echo ($startRow_RsCategorias + 1) ?> a <?php echo min($startRow_RsCategorias + $maxRows_RsCategorias, $totalRows_RsCategorias) ?>
<?php if ($pageNum_RsCategorias < $totalPages_RsCategorias) { // Show if not last page ?>
	
	  &#124;
      
  <a href="<?php printf("%s?pageNum_RsCategorias=%d%s", $currentPage, min($totalPages_RsCategorias, $pageNum_RsCategorias + 1), $queryString_RsCategorias); ?>" style="text-decoration:none; color:#900;"> &gt; </a>
  
  
  <a href="<?php printf("%s?pageNum_RsCategorias=%d%s", $currentPage, $totalPages_RsCategorias, $queryString_RsCategorias); ?>" style="text-decoration:none; color:#900;"> &gt;&gt; </a>
  <?php } // Show if not last page ?>
      </div>
            
      <div id="cadastraCateg">
            	Cadastrar nova categoria<hr style="margin-bottom:2px;"/>
                <form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
                  <table align="center">
                    <tr valign="baseline">
                      <td nowrap="nowrap" align="right">Descrição:</td>
                      <td><span id="sprycadastracateg">
                      <input type="text" name="descricao" value="" size="32" /><br />

                    <span class="textfieldRequiredMsg"><small>Campo obrigat&oacute;rio.</small></span>
                    <span class="textfieldMinCharsMsg"><small>M&iacute;nimo de 6 caracteres.</small></span>
                    <span class="textfieldMaxCharsMsg"><small>M&aacute;ximo de 45 caracteres.</small></span></span></td>
                    </tr>
                    <tr valign="baseline">
                      <td nowrap="nowrap" align="right">&nbsp;</td>
                      <td><input name="submit" type="submit" id="submit" onclick="MM_showHideLayers('listaCategoria','','show')" value="Cadastrar" />
                      <input name="cancela" type="button" id="cancela" onclick="MM_showHideLayers('listaCategoria','','show','cadastraCateg','','hide')" value="Cancelar" /></td>
                    </tr>
                  </table>
                  <input type="hidden" name="data_cadastro" value="<?php echo date('Y/m/d'); ?>" />
                  <input type="hidden" name="usuario_id" value="<?php echo $_SESSION['MM_loginid']; ?>" />
                  <input type="hidden" name="MM_insert" value="form1" />
                </form>
      </div>
            
		<div id="atualizaCateg">
        	Atualizar categoria (<?php echo $row_RsAtualizaCateg['descricao']; ?>)
            <hr style="margin-bottom:2px;"/>
            <form action="<?php echo $editFormAction; ?>" method="post" name="form2" id="form2">
              <table align="center">
                <tr valign="baseline">
                  <td nowrap="nowrap">Descrição:</td>
                  <td><span id="spryatualizacateg">
                    <input type="text" name="descricao2" value="<?php echo htmlentities($row_RsAtualizaCateg['descricao']); ?>" size="32" /><br />
            
                                <span class="textfieldRequiredMsg"><small>Campo obrigat&oacute;rio.</small></span>
                                <span class="textfieldMinCharsMsg"><small>M&iacute;nimo de 6 caracteres.</small></span>
                                <span class="textfieldMaxCharsMsg"><small>M&aacute;ximo de 45 caracteres</small></span></span></td>
                </tr>
                <tr valign="baseline">
                  <td align="right" nowrap="nowrap"></td>
                  <td>
                    <input name="Submit" type="submit" value="Atualizar" />
                    <input name="cancela2" type="button" id="cancela2" onclick="MM_showHideLayers('listaCategoria','','show','atualizaCateg','','hide')" value="Cancelar" /></td>
                </tr>
              </table>
              
                      <input type="hidden" name="data_cadastro" value="<?php echo htmlentities($row_RsAtualizaCateg['data_cadastro'], ENT_COMPAT, 'utf-8'); ?>" />
              <input type="hidden" name="usuario_id" value="<?php echo htmlentities($_SESSION['MM_loginid']); ?>" />
              <input type="hidden" name="MM_update" value="form2" />
              <input type="hidden" name="id" value="<?php echo $row_RsAtualizaCateg['id']; ?>" />
          </form>
      </div>
        
		<div id="excluiCateg">
        	Excluir categoria (<?php echo $row_RsExcluiCateg['descricao']; ?>)
<hr style="margin-bottom:2px;"/>
			<form id="form3" name="form3" method="post" action="categorias.php?delete=<?php echo $row_RsDelete['id']; ?>">
            	<input name="id"  type="hidden"  id="id" value="<?php echo $row_RsExcluiCateg['id']; ?>" size="2"/>
            	<input name="descricao" type="text" id="descricao" value="<?php echo $row_RsExcluiCateg['descricao']; ?>" readonly="readonly" />
                            <input name="delete" type="submit" value="Excluir"  />
                          <input name="cancela" type="button" id="button" onclick="MM_showHideLayers('listaCategoria','','show','excluiCateg','','hide')" value="Cancelar" />
                        
            </form>
      </div> 

    </div>
      
    </div>    
  </div>
<div id="rodape" style="width:100%; height:auto; padding:5px; position:fixed; background-color:#000; color:#fff; bottom:0px; text-align:center;">
   	  André Augusto Aguiar Gomes,
cursando Gest&atilde;o de Tecnologia da Informa&ccedil;&atilde;o.

31 3327-5397 &#124 31 99277-0410 &#124 andreaguiar.g@gmail.com
        </div>
</div>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprycadastracateg", "none", {minChars:6, maxChars:45});
var sprytextfield2 = new Spry.Widget.ValidationTextField("spryatualizacateg", "none", {minChars:6, maxChars:45});
</script>
</body>
</html>
<?php
mysql_free_result($RsCategorias);

mysql_free_result($RsAtualizaCateg);

mysql_free_result($RsExcluiCateg);
?>
