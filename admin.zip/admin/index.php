<?php require_once('../Connections/Controle_Prod.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}
// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}
if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  $_SESSION['MM_status'] = $loginStatus - 1;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
  unset($_SESSION['MM_status']);
	
  $logoutGoTo = "../index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$maxRows_RsUsuario = 10;
$pageNum_RsUsuario = 0;
if (isset($_GET['pageNum_RsUsuario'])) {
  $pageNum_RsUsuario = $_GET['pageNum_RsUsuario'];
}
$startRow_RsUsuario = $pageNum_RsUsuario * $maxRows_RsUsuario;

mysql_select_db($database_Controle_Prod, $Controle_Prod);
$query_RsUsuario = "SELECT * FROM usuario ORDER BY id ASC";
$query_limit_RsUsuario = sprintf("%s LIMIT %d, %d", $query_RsUsuario, $startRow_RsUsuario, $maxRows_RsUsuario);
$RsUsuario = mysql_query($query_limit_RsUsuario, $Controle_Prod) or die(mysql_error());
$row_RsUsuario = mysql_fetch_assoc($RsUsuario);

if (isset($_GET['totalRows_RsUsuario'])) {
  $totalRows_RsUsuario = $_GET['totalRows_RsUsuario'];
} else {
  $all_RsUsuario = mysql_query($query_RsUsuario);
  $totalRows_RsUsuario = mysql_num_rows($all_RsUsuario);
}
$totalPages_RsUsuario = ceil($totalRows_RsUsuario/$maxRows_RsUsuario)-1;

$colname_RsAtualiza = "-1";
if (isset($_GET['atualiza'])) {
  $colname_RsAtualiza = $_GET['atualiza'];
}
mysql_select_db($database_Controle_Prod, $Controle_Prod);
$query_RsAtualiza = sprintf("SELECT * FROM usuario WHERE id = %s ORDER BY id ASC", GetSQLValueString($colname_RsAtualiza, "int"));
$RsAtualiza = mysql_query($query_RsAtualiza, $Controle_Prod) or die(mysql_error());
$row_RsAtualiza = mysql_fetch_assoc($RsAtualiza);
$totalRows_RsAtualiza = mysql_num_rows($RsAtualiza);

$colname_RsDelete = "-1";
if (isset($_GET['exclui'])) {
  $colname_RsDelete = $_GET['exclui'];
}
mysql_select_db($database_Controle_Prod, $Controle_Prod);
$query_RsDelete = sprintf("SELECT * FROM usuario WHERE id = %s ORDER BY id ASC", GetSQLValueString($colname_RsDelete, "int"));
$RsDelete = mysql_query($query_RsDelete, $Controle_Prod) or die(mysql_error());
$row_RsDelete = mysql_fetch_assoc($RsDelete);
$totalRows_RsDelete = mysql_num_rows($RsDelete);

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {	
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO usuario (login, pass, firstname, lastname, data_cadastro) VALUES (%s, md5(%s), %s, %s, %s)",
                       GetSQLValueString($_POST['login'], "text"),
                       GetSQLValueString($_POST['password'], "text"),
                       GetSQLValueString($_POST['firstname2'], "text"),
                       GetSQLValueString($_POST['lastname2'], "text"),
                       GetSQLValueString($_POST['data_cadastro'], "text"));

  mysql_select_db($database_Controle_Prod, $Controle_Prod);
  $Result1 = mysql_query($insertSQL, $Controle_Prod) or die(mysql_error());

  $insertGoTo = "index.php?cadastro=sucesso";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "editaform")) {
  $updateSQL = sprintf("UPDATE usuario SET login=%s, pass=md5(%s), firstname=%s, lastname=%s, data_cadastro=%s, status=%s WHERE id=%s",
                       GetSQLValueString($_POST['editausuario'], "text"),
                       GetSQLValueString($_POST['editausuario'], "text"),
                       GetSQLValueString($_POST['editausuario'], "text"),
                       GetSQLValueString($_POST['editausuario'], "text"),
                       GetSQLValueString($_POST['editausuario'], "text"),
                       GetSQLValueString($_POST['editausuario'], "int"),
                       GetSQLValueString($_POST['editausuario'], "int"));

  mysql_select_db($database_Controle_Prod, $Controle_Prod);
  $Result1 = mysql_query($updateSQL, $Controle_Prod) or die(mysql_error());

  $updateGoTo = "index.php?atualiza=sucesso";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

if ((isset($_POST['id'])) && ($_POST['id'] != "") && (isset($_GET['delete']))) {
  $deleteSQL = sprintf("DELETE FROM usuario WHERE id=%s",
                       GetSQLValueString($_POST['id'], "int"));

  mysql_select_db($database_Controle_Prod, $Controle_Prod);
  $Result1 = mysql_query($deleteSQL, $Controle_Prod) or die(mysql_error());

  $deleteGoTo = "index.php?exclui=sucesso";
  if (isset($_SERVER['QUERY_STRING'])) {
    $deleteGoTo .= (strpos($deleteGoTo, '?')) ? "&" : "?";
    $deleteGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $deleteGoTo));
}

$queryString_RsUsuario = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_RsUsuario") == false && 
        stristr($param, "totalRows_RsUsuario") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_RsUsuario = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_RsUsuario = sprintf("&totalRows_RsUsuario=%d%s", $totalRows_RsUsuario, $queryString_RsUsuario);
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true;
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}
$MM_restrictGoTo = "../index.php?acesso=erro";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Administra Usuários</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css" />

<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />

<style>
	html,body{
		border:0;
  -webkit-text-size-adjust: 100%;
      -ms-text-size-adjust: 100%;
	}
	#topo{
		width:100%;
	}
	hr{
		position:relative;
		clear:both;
	}
	#geral #topo #pg_titulo {
		font-weight: bold;
		width:100%;
		position:relative;
		float:left;
		padding:2px;
		background-color:#000;
		color:#fff;
		font-size:24px;
		clear:both;
	}
	#sessao{		
		text-align: right;
		position:relative;
		float: right;
		clear:both;
		margin:15px;
	}
	#lista{
		width:75%;
		position:relative;
		margin:0 auto;
		clear:both;
		z-index:5;
	}
	#cadastrarUsuario {
	width: 100%;
	position: absolute;
	margin: 0 auto;
	top: 130px;
	height: auto;
	padding: 10px;
	z-index: 2;
	background-color: #FFFFFF;
	box-shadow: #999 2px 2px 5px 5px;
	visibility: hidden;
	}
	#editarUsuario {
		width: 100%;
		position: absolute;
		margin: 0 auto;
		top: 130px;
		height: auto;
		padding: 10px;
		z-index: 1;
		background-color: #FFFFFF;
		box-shadow: #999 2px 2px 5px 5px;
		visibility: hidden;
		}
	#listaUsuario {
	width: 100%;
	position: absolute;
	margin: 0 auto;
	top: 130px;
	height: auto;
	padding: 10px;
	z-index: 1;
	background-color: #FFFFFF;
	box-shadow: #999 2px 2px 5px 5px;
	visibility: visible;
		}
	#atualizaUsuario {
	width: 100%;
	position: absolute;
	margin: 0 auto;
	top: 130px;
	height: auto;
	padding: 10px;
	z-index: 3;
	background-color: #FFFFFF;
	box-shadow: #999 2px 2px 5px 5px;
	visibility: hidden;
	}
	#excluiUsuario {
	width: 100%;
	position: absolute;
	margin: 0 auto;
	top: 130px;
	height: auto;
	padding: 10px;
	z-index: 4;
	background-color: #FFFFFF;
	box-shadow: #999 2px 2px 5px 5px;
	visibility: hidden;
	}
	#conteudo #lista #listaUsuario table tr {
		text-align: center;
	}
	#conteudo #lista #listaUsuario table th {
		border-bottom:#999 1px solid;
	}
	#conteudo #lista #listaUsuario table td {
	border-bottom: #333 1px solid;
	border-left: #666 1px solid;
	font-weight: normal;
	}
	#conteudo #lista #listaUsuario table td a{
		text-decoration:none;
		color:#900;
	}
	#conteudo #lista #listaUsuario table td a:hover{
		text-decoration:none;
		color: #666;
	}
	#geral #conteudo #lista #cadastrarUsuario {
		text-align: center;
	}
	#geral #conteudo #lista #cadastrarUsuario {
		font-weight: bold;
	}
	#geral #conteudo #lista #cadastrarUsuario #form1 table {
		text-align: left;
	}
	#geral #conteudo #lista #atualizaUsuario {
		text-align: center;
	}
	#geral #conteudo #lista #atualizaUsuario {
		font-weight: bold;
	}
	#geral #conteudo #lista #atualizaUsuario #form2 table {
		text-align: left;
	}
	#geral #conteudo #lista #listaUsuario {
		text-align: center;
	}
	#geral #conteudo #lista #listaUsuario {
		font-weight: bold;
	}
	#geral #conteudo #lista #excluiUsuario {
	}
	#geral #conteudo #lista #excluiUsuario {
	font-weight: bold;
	text-align: center;
	}
#geral #conteudo #lista #ls_titulo {
	text-align: center;
}
</style>
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script type="text/javascript">
function MM_showHideLayers() { //v9.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) 
  with (document) if (getElementById && ((obj=getElementById(args[i]))!=null)) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
    obj.visibility=v; }
}
function MM_goToURL() { //v3.0
  var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
  for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
}
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
</script>
</head>

<body>
<div id="geral">
          <div id="topo">
            <span id="pg_titulo">
                    Administrar Usu&aacute;rios<br />
            </span>
    <div style="position: absolute; clear:both; float:left; left:15px; top:33px; vertical-align: text-top; ">
    <img src="../imagens/logo.jpg" width="90" height="90" style="alignment-baseline:central;" />
    
    <span style="width: 309px; text-align: left; font-size: 14px; position: absolute; clear: both; top: 3px; left: 104px; line-height: 130%; height: 97px;"> <b>Test Programming Language</b><br />

T (31) 3515-0800, F (31) 3516-0801
comercial@freebsdbrasil.com.br
http://www.freebsdbrasil.com.br
      <br />
Av Getulio Vargas, 54 - 3 andar, Belo Horizonte MG</span></div>
   	
                    
                    <span id="sessao">
                        Ol&aacute; Sr(a).<b>
                        <?php echo $_SESSION['MM_lname']; ?></b>, <b><?php echo $_SESSION['MM_fname']; ?>(a)</b>!<br />
                        
Seja bem vindo(a)!<br />
Você est&aacute;. <?php echo $_SESSION['MM_status']; ?><a href="<?php echo $logoutAction ?>"><input name="logout" type="button" value="Sair" /></a>
					</span>
</div>    <hr />      
<div id="conteudo">
                <div id="lista">
                  <span id="ls_titulo">
                  <h2>Op&ccedil;&otilde;es de Administrador</h2>

                  <span>
                  
                  <font size="+1">
                  
                      <div id="ls_menu">
                              <a href="index.php">Adiministrar Usu&aacute;rios</a> &#124;
                              <a href="produtos.php">Adiministrar Produtos</a> &#124;
                              <a href="categorias.php">Adiministrar Categorias</a>
                      </div>
                  </font>
    <hr style="margin-bottom:-15; margin-top:0px;"/>
                  </span>
                  <br />
                  </span>
                      <span id="lnk_cadastro">
                        
      
                        
      	<div style="position: absolute;"> 
                       Usu&aacute;rio: <a href="#" onclick="MM_showHideLayers('listaUsuario','','show','cadastrarUsuario','','hide','atualizaUsuario','','hide','excluiUsuario','','hide')"><strong>Visualizar</strong></a> &#124 
                        
                        <a href="#" onclick="MM_showHideLayers('listaUsuario','','hide','cadastrarUsuario','','show','atualizaUsuario','','hide','excluiUsuario','','hide')"><strong>Novo</strong></a>
                        
                &#124;
                
                
                <span  style="position: relative; display:inline-block; clear:both;">
          </span>
          
          <span  style="position: relative; display:inline-block; clear:both;">
<form method="POST" action="<?php echo $editFormAction; ?>" name="editaform" target="_self" id="editaform"  style="position: relative; visibility: visible;"> 
                  
          <select name="editausuario" id="editausuario" onchange="MM_goToURL('parent','index.php?atualiza=<?php echo $row_RsUsuario['id']; ?>#');return document.MM_returnValue" onmouseout="MM_jumpMenu('parent',this,0)">
            <?php
    do {  
    ?>
            <option value="?atualiza=<?php echo $row_RsUsuario['id']; ?>#" selected="selected"<?php if (!(strcmp($row_RsUsuario['id'], $row_RsUsuario['id']))) {echo "selected=\"selected\"";} ?>><?php echo $row_RsUsuario['login']?></option>
            <?php
    } while ($row_RsUsuario = mysql_fetch_assoc($RsUsuario));
      $rows = mysql_num_rows($RsUsuario);
      if($rows > 0) {
          mysql_data_seek($RsUsuario, 0);
          $row_RsUsuario = mysql_fetch_assoc($RsUsuario);
      }
    ?>
          </select>                 
             
          
          <a href="#" onclick="MM_showHideLayers('listaUsuario','','hide','cadastrarUsuario','','hide','atualizaUsuario','','show','excluiUsuario','','hide')"><strong >Editar </strong></a>
          <input type="hidden" name="MM_update" value="editaform" />
          </form>
      
          </span>
          
      &#124 
      
      
      <span  style="position: relative; display:inline-block; clear:both;">
<form action="index.php?exclui=<?php echo $row_RsUsuario['id']; ?>#" name="formexclui" target="_self" id="formexclui"  style="position: relative; visibility: visible;"> 
                  
          <select name="excluiusuario" id="excluiusuario" onchange="MM_goToURL('parent','index.php?exclui=<?php echo $row_RsUsuario['id']; ?>#');return document.MM_returnValue" onmouseout="MM_jumpMenu('parent',this,0)">
            <?php
    do {  
    ?>
            <option value="?exclui=<?php echo $row_RsUsuario['id']; ?>#" selected="selected"<?php if (!(strcmp($row_RsUsuario['id'], $row_RsUsuario['id']))) {echo "selected=\"selected\"";} ?>><?php echo $row_RsUsuario['login']?></option>
            <?php
    } while ($row_RsUsuario = mysql_fetch_assoc($RsUsuario));
      $rows = mysql_num_rows($RsUsuario);
      if($rows > 0) {
          mysql_data_seek($RsUsuario, 0);
          $row_RsUsuario = mysql_fetch_assoc($RsUsuario);
      }
    ?>
          </select>                 
             
          
          <a href="#" onclick="MM_showHideLayers('listaUsuario','','hide','cadastrarUsuario','','hide','atualizaUsuario','','hide','excluiUsuario','','show')"><strong >Excluir </strong></a>
        </form>
      
          </span>
      
      
      </div>    
                
                <div id="cadastrarUsuario">
                  	Cadastrar novo administrador<hr style="margin-bottom:2px;"/>
                      <form action="<?php echo $editFormAction; ?>" method="POST" name="form1" id="form1">
                        <table align="center">
                          <tr valign="baseline">
                            <td nowrap="nowrap" align="right"><strong>Login:</strong></td>
                            <td><span id="sprylogin">
                            <input type="text" name="login" value="" size="32" /><br />

                    <span class="textfieldRequiredMsg"><small>Campo obrigat&oacute;rio.</small></span>
                    <span class="textfieldMinCharsMsg"><small>M&iacute;nimo de 6 caracteres.</small></span>
                    <span class="textfieldMaxCharsMsg"><small>M&aacute;ximo de 45 caracteres.</small></span></span></td>
                          </tr>
                          <tr valign="baseline">
                            <td nowrap="nowrap" align="right"><strong>Senha:</strong></td>
                            <td><span id="sprysenha">
                              <input name="password" type="password" value="" size="20" maxlength="10" /><br />

                    <span class="textfieldRequiredMsg"><small>Campo obrigat&oacute;rio.</small></span>
                    <span class="textfieldMinCharsMsg"><small>M&iacute;nimo de 5 caracteres.</small></span>
                    <span class="textfieldMaxCharsMsg"><small>M&aacute;ximo de 10 caracteres.</small></span></span></td>
                          </tr>
                          <tr valign="baseline">
                            <td nowrap="nowrap" align="right"><strong>Nome:</strong></td>
                            <td><span id="sprynome">
                            <input type="text" name="firstname2" value="" size="32" /><br />

                    <span class="textfieldRequiredMsg"><small>Campo obrigat&oacute;rio.</small></span>
                    <span class="textfieldMinCharsMsg"><small>M&iacute;nimo de 6 caracteres.</small></span>
                    <span class="textfieldMaxCharsMsg"><small>M&aacute;ximo de 45 caracteres.</small></span></span></td>
                          </tr>
                          <tr valign="baseline">
                            <td nowrap="nowrap" align="right"><strong>Sobrenome:</strong></td>
                            <td><span id="sprysobrenome">
                            <input type="text" name="lastname2" value="" size="32" /><br />

                    <span class="textfieldRequiredMsg"><small>Campo obrigat&oacute;rio.</small></span>
                    <span class="textfieldMinCharsMsg"><small>M&iacute;nimo de 6 caracteres.</small></span>
                    <span class="textfieldMaxCharsMsg"><small>M&aacute;ximo de 45 caracteres.</small></span></span></td>
                          </tr>
                          <tr valign="baseline">
                            <td nowrap="nowrap" align="right">&nbsp;</td>
                            <td><input name="submit" type="submit" id="submit" onclick="MM_showHideLayers('listaUsuario','','show')" value="Cadastrar" />
                            <input name="cancelar" type="button" id="cancelar" onclick="MM_showHideLayers('cadastrarUsuario','','hide','listaUsuario','','show')" value="Cancelar" /></td>
                          </tr>
                        </table>
                        <input type="hidden" name="data_cadastro" value="<?php echo date('Y/m/d'); ?>" />
                        <input type="hidden" name="MM_insert" value="form1" />
                    </form>
                    	
                  </div>
                    
                    
				  <div id="listaUsuario">
                  	<h3>Administradores cadastrados</h3>
                  	<hr style="margin-bottom:2px;"/>
                      <table border="0" align="center" cellpadding="3" cellspacing="3" width="100%">
                        <tr>
                          <th>ID</th>
                          <th>Login</th>
                          <th>Nome</th>
                          <th>Sobrenome</th>
                          <th>Data do Cadastro</th>
                        </tr>
                        <?php do { ?>
                          <tr>
                            <td><?php echo $row_RsUsuario['id']; ?></td>
                            <td><?php echo $row_RsUsuario['login']; ?></td>
                            <td><?php echo $row_RsUsuario['firstname']; ?></td>
                            <td><?php echo $row_RsUsuario['lastname']; ?></td>
                            <td style="border-right:#333 1px solid;"><?php echo $row_RsUsuario['data_cadastro']; ?></td>
                          </tr>
                          <?php } while ($row_RsUsuario = mysql_fetch_assoc($RsUsuario)); ?>
                      </table>
                      <?php if ($pageNum_RsUsuario > 0) { // Show if not first page ?>
  <a href="<?php printf("%s?pageNum_RsUsuario=%d%s", $currentPage, 0, $queryString_RsUsuario); ?>"> &lt;&lt; </a>
                        
                        <a href="<?php printf("%s?pageNum_RsUsuario=%d%s", $currentPage, max(0, $pageNum_RsUsuario - 1), $queryString_RsUsuario); ?>"> &lt; </a>
                        
                        
	  &#124;
                        <?php } // Show if not first page ?>
<?php echo ($startRow_RsUsuario + 1) ?> a <?php echo min($startRow_RsUsuario + $maxRows_RsUsuario, $totalRows_RsUsuario) ?>
<?php if ($pageNum_RsUsuario < $totalPages_RsUsuario) { // Show if not last page ?>

	  &#124;
  <a href="<?php printf("%s?pageNum_RsUsuario=%d%s", $currentPage, min($totalPages_RsUsuario, $pageNum_RsUsuario + 1), $queryString_RsUsuario); ?>">&gt; </a> <a href="<?php printf("%s?pageNum_RsUsuario=%d%s", $currentPage, $totalPages_RsUsuario, $queryString_RsUsuario); ?>">&gt;&gt;</a>
  <?php } // Show if not last page ?>
                  </div>     
                        
                  <div id="atualizaUsuario"> Atualizar administrador (<?php echo $row_RsAtualiza['firstname']; ?> <?php echo $row_RsAtualiza['lastname']; ?>)
<hr style="margin-bottom:2px;"/>
                        <form method="post" name="form2" id="form2">
                          <table align="center">
                            <tr valign="baseline">
                              <td nowrap="nowrap" align="right">Login:</td>
                              <td><span id="spryatualizalogin">
                                <input type="text" name="login" value="<?php echo htmlentities($row_RsAtualiza['login']); ?>" size="32" /><br />

                    <span class="textfieldRequiredMsg"><small>Campo obrigat&oacute;rio.</small></span>
                    <span class="textfieldMinCharsMsg"><small>M&iacute;nimo de 6 caracteres.</small></span>
                    <span class="textfieldMaxCharsMsg"><small>M&aacute;ximo de 45 caracteres.</small></span></span></td>
                            </tr>
                            <tr valign="baseline">
                              <td nowrap="nowrap" align="right">Senha:</td>
                              <td><span id="spryatualizasenha">
                                <input type="password" name="pass" value="<?php echo htmlentities($row_RsAtualiza['pass'], ENT_COMPAT, 'utf-8'); ?>" size="32" /><br />

                    <span class="textfieldRequiredMsg"><small>Campo obrigat&oacute;rio.</small></span>
                    <span class="textfieldMinCharsMsg"><small>M&iacute;nimo de 5 caracteres.</small></span>
                    <span class="textfieldMaxCharsMsg"><small>M&aacute;ximo de 10 caracteres.</small></span></span></td>
                            </tr>
                            <tr valign="baseline">
                              <td nowrap="nowrap" align="right">Nome:</td>
                              <td><span id="spryatualizanome">
                                <input type="text" name="firstname" value="<?php echo htmlentities($row_RsAtualiza['firstname'], ENT_COMPAT, 'utf-8'); ?>" size="32" /><br />

                    <span class="textfieldRequiredMsg"><small>Campo obrigat&oacute;rio.</small></span>
                    <span class="textfieldMinCharsMsg"><small>M&iacute;nimo de 6 caracteres.</small></span>
                    <span class="textfieldMaxCharsMsg"><small>M&aacute;ximo de 45 caracteres.</small></span></span></td>
                            </tr>
                            <tr valign="baseline">
                              <td nowrap="nowrap" align="right">Sobre nome:</td>
                              <td><span id="spryatualizasobrenome">
                                <input type="text" name="lastname" value="<?php echo htmlentities($row_RsAtualiza['lastname']); ?>" size="32" /><br />

                    <span class="textfieldRequiredMsg"><small>Campo obrigat&oacute;rio.</small></span>
                    <span class="textfieldMinCharsMsg"><small>M&iacute;nimo de 6 caracteres.</small></span>
                    <span class="textfieldMaxCharsMsg"><small>M&aacute;ximo de 45 caracteres.</small></span></span></td>
                            </tr>
                            <tr valign="baseline">
                              <td nowrap="nowrap" align="right"></td>
                              <td><input name="submit" type="submit" id="submit" value="Atualizar" />
                              <input name="cancelar2" type="button" id="cancelar2" onclick="MM_showHideLayers('listaUsuario','','show','atualizaUsuario','','hide')" value="Cancelar" /></td>
                            </tr>
                          </table>
                          <input type="hidden" name="id" value="<?php echo $row_RsAtualiza['id']; ?>" />

                        <input type="hidden" name="data_cadastro" value="<?php echo $row_RsAtualiza['data_cadastro']; ?>" />
                    </form>
                  </div>
                    
					<div id="excluiUsuario">
                    	Excluir administrador (<?php echo $row_RsDelete['firstname']; ?> <?php echo $row_RsDelete['lastname']; ?>)
<hr style="margin-bottom:2px;"/>

                        <form id="form3" name="form3" method="post" action="index.php?delete=<?php echo $row_RsDelete['id']; ?>">
                          <input name="id" type="hidden" id="hiddenField" value="<?php echo $row_RsDelete['id']; ?>" />
                          Login: <input name="login" type="text" value="<?php echo $row_RsDelete['login']; ?>" size="" readonly="readonly" style="width:auto;" />
                          Nome: <input name="login" type="text" value="<?php echo $row_RsDelete['firstname']; ?>" size="" readonly="readonly" style="width:auto;" />
                          Sobrenome: <input name="login" type="text" value="<?php echo $row_RsDelete['lastname']; ?>" size="" readonly="readonly" />
                            <input name="delete" type="submit" value="Excluir"  />
                          <input name="cancela" type="button" id="button" onclick="MM_showHideLayers('listaUsuario','','show','excluiUsuario','','hide')" value="Cancelar" />
                  </form>                     </div>   
    </div>
  </div>
           
<div id="rodape" style="width:100%; height:auto; padding:5px; position:fixed; background-color:#000; color:#fff; bottom:0px; text-align:center;">
   	  André Augusto Aguiar Gomes,
cursando Gest&atilde;o de Tecnologia da Informa&ccedil;&atilde;o.

31 3327-5397 &#124 31 99277-0410 &#124 andreaguiar.g@gmail.com
  </div>
</div>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprylogin", "none", {minChars:5, maxChars:45});
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprysenha", "none", {minChars:5, maxChars:10});
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprynome", "none", {minChars:5, maxChars:45});
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprysobrenome", "none", {minChars:5, maxChars:45});
var sprytextfield9 = new Spry.Widget.ValidationTextField("spryatualizalogin", "none", {minChars:5, maxChars:45});
var sprytextfield10 = new Spry.Widget.ValidationTextField("spryatualizasenha", "none", {minChars:5, maxChars:10});
var sprytextfield5 = new Spry.Widget.ValidationTextField("spryatualizanome", "none", {minChars:5, maxChars:45});
var sprytextfield6 = new Spry.Widget.ValidationTextField("spryatualizasobrenome", "none", {minChars:5, maxChars:45});
</script>
</body>
</html>
<?php
mysql_free_result($RsUsuario);

mysql_free_result($RsAtualiza);

mysql_free_result($RsDelete);
?>
