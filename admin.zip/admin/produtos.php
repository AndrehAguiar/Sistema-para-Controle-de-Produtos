<?php require_once('../Connections/Controle_Prod.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "../index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "../index.php?acesso=erro";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO produto (descricao, quantidade, valorproduto, usuario_id, data_cadastro, categoria_id) VALUES (%s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['descricao'], "text"),
                       GetSQLValueString($_POST['quantidade'], "text"),
                       GetSQLValueString($_POST['valorproduto'], "text"),
                       GetSQLValueString($_POST['usuario_id'], "int"),
                       GetSQLValueString($_POST['data_cadastro'], "date"),
                       GetSQLValueString($_POST['categoria_id'], "int"));

  mysql_select_db($database_Controle_Prod, $Controle_Prod);
  $Result1 = mysql_query($insertSQL, $Controle_Prod) or die(mysql_error());

  $insertGoTo = "produtos.php?cadastro=sucesso";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form2")) {
  $updateSQL = sprintf("UPDATE produto SET descricao=%s, quantidade=%s, valorproduto=%s, usuario_id=%s, data_cadastro=%s, categoria_id=%s WHERE id=%s",
                       GetSQLValueString($_POST['descricao'], "text"),
                       GetSQLValueString($_POST['quantidade'], "text"),
                       GetSQLValueString($_POST['valorproduto'], "text"),
                       GetSQLValueString($_POST['usuario_id'], "int"),
                       GetSQLValueString($_POST['data_cadastro'], "date"),
                       GetSQLValueString($_POST['categoria_id'], "int"),
                       GetSQLValueString($_POST['id'], "int"));

  mysql_select_db($database_Controle_Prod, $Controle_Prod);
  $Result1 = mysql_query($updateSQL, $Controle_Prod) or die(mysql_error());

  $updateGoTo = "produtos.php?atualiza=sucesso";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form2")) {
  $updateSQL = sprintf("UPDATE produto SET descricao=%s, quantidade=%s, valorproduto=%s, usuario_id=%s, data_cadastro=%s, categoria_id=%s WHERE id=%s",
                       GetSQLValueString($_POST['descricao'], "text"),
                       GetSQLValueString($_POST['quantidade'], "text"),
                       GetSQLValueString($_POST['valorproduto'], "text"),
                       GetSQLValueString($_POST['usuario_id'], "int"),
                       GetSQLValueString($_POST['data_cadastro'], "date"),
                       GetSQLValueString($_POST['categoria_id'], "int"),
                       GetSQLValueString($_POST['id'], "int"));

  mysql_select_db($database_Controle_Prod, $Controle_Prod);
  $Result1 = mysql_query($updateSQL, $Controle_Prod) or die(mysql_error());

  $updateGoTo = "produtos.php?atualiza=sucesso";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

if ((isset($_POST['id'])) && ($_POST['id'] != "") && (isset($_GET['delete']))) {
  $deleteSQL = sprintf("DELETE FROM produto WHERE id=%s",
                       GetSQLValueString($_POST['id'], "int"));

  mysql_select_db($database_Controle_Prod, $Controle_Prod);
  $Result1 = mysql_query($deleteSQL, $Controle_Prod) or die(mysql_error());

  $deleteGoTo = "produtos.php?exclui=sucesso";
  if (isset($_SERVER['QUERY_STRING'])) {
    $deleteGoTo .= (strpos($deleteGoTo, '?')) ? "&" : "?";
    $deleteGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $deleteGoTo));
}

$maxRows_RsProdutos = 10;
$pageNum_RsProdutos = 0;
if (isset($_GET['pageNum_RsProdutos'])) {
  $pageNum_RsProdutos = $_GET['pageNum_RsProdutos'];
}
$startRow_RsProdutos = $pageNum_RsProdutos * $maxRows_RsProdutos;

mysql_select_db($database_Controle_Prod, $Controle_Prod);
$query_RsProdutos = "SELECT * FROM produto ORDER BY categoria_id ASC";
$query_limit_RsProdutos = sprintf("%s LIMIT %d, %d", $query_RsProdutos, $startRow_RsProdutos, $maxRows_RsProdutos);
$RsProdutos = mysql_query($query_limit_RsProdutos, $Controle_Prod) or die(mysql_error());
$row_RsProdutos = mysql_fetch_assoc($RsProdutos);

if (isset($_GET['totalRows_RsProdutos'])) {
  $totalRows_RsProdutos = $_GET['totalRows_RsProdutos'];
} else {
  $all_RsProdutos = mysql_query($query_RsProdutos);
  $totalRows_RsProdutos = mysql_num_rows($all_RsProdutos);
}
$totalPages_RsProdutos = ceil($totalRows_RsProdutos/$maxRows_RsProdutos)-1;

mysql_select_db($database_Controle_Prod, $Controle_Prod);
$query_RsCategoria = "SELECT * FROM categoria ORDER BY id ASC";
$RsCategoria = mysql_query($query_RsCategoria, $Controle_Prod) or die(mysql_error());
$row_RsCategoria = mysql_fetch_assoc($RsCategoria);
$totalRows_RsCategoria = mysql_num_rows($RsCategoria);

$colname_RsAtualizaProd = "-1";
if (isset($_GET['atualiza'])) {
  $colname_RsAtualizaProd = $_GET['atualiza'];
}
mysql_select_db($database_Controle_Prod, $Controle_Prod);
$query_RsAtualizaProd = sprintf("SELECT * FROM produto WHERE id = %s ORDER BY id ASC", GetSQLValueString($colname_RsAtualizaProd, "int"));
$RsAtualizaProd = mysql_query($query_RsAtualizaProd, $Controle_Prod) or die(mysql_error());
$row_RsAtualizaProd = mysql_fetch_assoc($RsAtualizaProd);
$totalRows_RsAtualizaProd = mysql_num_rows($RsAtualizaProd);

mysql_select_db($database_Controle_Prod, $Controle_Prod);
$query_RsAtualizaCateg = "SELECT * FROM categoria";
$RsAtualizaCateg = mysql_query($query_RsAtualizaCateg, $Controle_Prod) or die(mysql_error());
$row_RsAtualizaCateg = mysql_fetch_assoc($RsAtualizaCateg);
$totalRows_RsAtualizaCateg = mysql_num_rows($RsAtualizaCateg);

$colname_RsExcluiProd = "-1";
if (isset($_GET['exclui'])) {
  $colname_RsExcluiProd = $_GET['exclui'];
}
mysql_select_db($database_Controle_Prod, $Controle_Prod);
$query_RsExcluiProd = sprintf("SELECT * FROM produto WHERE id = %s", GetSQLValueString($colname_RsExcluiProd, "int"));
$RsExcluiProd = mysql_query($query_RsExcluiProd, $Controle_Prod) or die(mysql_error());
$row_RsExcluiProd = mysql_fetch_assoc($RsExcluiProd);
$totalRows_RsExcluiProd = mysql_num_rows($RsExcluiProd);

$queryString_RsProdutos = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_RsProdutos") == false && 
        stristr($param, "totalRows_RsProdutos") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_RsProdutos = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_RsProdutos = sprintf("&totalRows_RsProdutos=%d%s", $totalRows_RsProdutos, $queryString_RsProdutos);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Administra Produtos</title>
<link href="../css/estilo.css" rel="stylesheet" type="text/css" />

<link href="../SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="../SpryAssets/SpryValidationSelect.css" rel="stylesheet" type="text/css" />

<style>
	
	#sessao{		
		text-align: right;
		position:relative;
		float: right;
		clear:both;
		margin:15px;
	}
	#lista{
	width: 75%;
	position: relative;
	margin: 0 auto;
	clear: both;
	z-index: 5;
	visibility: visible;
	}
	#geral #conteudo #lista #ls_titulo {
		text-align: center;
	}
	#listaProduto {
	width: 100%;
	height: auto;
	position: absolute;
	margin: 0 auto;
	top: 130px;
	padding: 10px;
	background-color: #FFFFFF;
	box-shadow: #999 2px 2px 5px 5px;
	z-index: 4;
	visibility: visible;
	}
	#geral #conteudo #lista #listaProduto {
		text-align: center;
	}
	#geral #conteudo #lista #listaProduto {
		font-weight: bold;
	}
	#conteudo #listaProduto table th {
		border-bottom:#999 1px solid;
	}
	#conteudo #listaProduto table td {
		border-bottom: #333 1px solid;
		border-left: #666 1px solid;
		font-weight: normal;
	}
	#conteudo #listaProduto table td a{
		text-decoration:none;
		color:#900;
	}
	#conteudo #listaProduto table td a:hover{
		text-decoration:none;
		color: #666;
	}
	#cadastraProd {
	width: 100%;
	position: absolute;
	margin: 0 auto;
	top: 130px;
	height: auto;
	padding: 10px;
	background-color: #FFFFFF;
	box-shadow: #999 2px 2px 5px 5px;
	z-index: 7;
	visibility: hidden;
	}
	#atualizaProd {
	width: 100%;
	position: absolute;
	margin: 0 auto;
	top: 130px;
	height: auto;
	padding: 10px;
	background-color: #FFFFFF;
	box-shadow: #999 2px 2px 5px 5px;
	z-index: 5;
	visibility: hidden;
	}
	#excluiProd {
	width: 100%;
	position: absolute;
	margin: 0 auto;
	top: 130px;
	height: auto;
	padding: 10px;
	background-color: #FFFFFF;
	box-shadow: #999 2px 2px 5px 5px;
	z-index: 5;
	visibility: hidden;
	}
#conteudo #lista #cadastraProd {
	text-align: center;
}
#conteudo #lista #cadastraProd {
	font-weight: bold;
	text-align: left;
}
#conteudo #lista #atualizaProd {
	text-align: center;
}
#conteudo #lista #atualizaProd {
	font-weight: bold;
}
#conteudo #lista #atualizaProd #form2 table {
	text-align: left;
}
#conteudo #lista #cadastraProd {
	text-align: center;
}
#conteudo #lista #cadastraProd #form1 table {
	text-align: left;
}
#conteudo #lista #listaProduto {
}
#geral #conteudo #lista #excluiProd strong {
	text-align: center;
}
#geral #conteudo #lista #excluiProd {
	text-align: center;
}
#geral #conteudo #lista #excluiProd {
	font-weight: bold;
}
</style>
<script src="../SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="../SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>
<script type="text/javascript">
function MM_showHideLayers() { //v9.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) 
  with (document) if (getElementById && ((obj=getElementById(args[i]))!=null)) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
    obj.visibility=v; }
}
function MM_goToURL() { //v3.0
  var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
  for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
}

function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
</script>
</head>

<body>
<div id="geral">
          <div id="topo">
            <span id="pg_titulo">
                    <strong>Administrar Produtos</strong><br />
            </span>
    <div style="position: absolute; clear:both; float:left; left:15px; top:33px;">
    <img src="../imagens/logo.jpg" width="90" height="90" style="alignment-baseline:central;" />
    
    <span style="width: 309px; text-align: left; font-size: 14px; position: absolute; clear: both; top: 3px; left: 104px; line-height: 130%; height: 97px;"> <b>Test Programming Language</b><br />

T (31) 3515-0800, F (31) 3516-0801
comercial@freebsdbrasil.com.br
http://www.freebsdbrasil.com.br
      <br />
Av Getulio Vargas, 54 - 3 andar, Belo Horizonte MG</span></div>
   	
                    <span id="sessao">
                        Ol&aacute; Sr(a).<b>
                        <?php echo $_SESSION['MM_lname']; ?></b>, <b><?php echo $_SESSION['MM_fname']; ?>(a)</b>!<br />
Seja bem vindo(a)!<br />
<a href="<?php echo $logoutAction ?>"><input name="logout" type="button" value="Sair" /></a>

</div> <hr />
<div id="conteudo">
  <div id="lista">
                  <span id="ls_titulo">
   
                  <h2>Op&ccedil;&otilde;es de Administrador</h2>
                      <span>
                      
                      <font size="+1">
                      <div id="ls_menu">
                              <a href="index.php">Adiministrar Usu&aacute;rios</a> &#124;
                              <a href="produtos.php">Adiministrar Produtos</a> &#124;
                              <a href="categorias.php">Adiministrar Categorias</a>
                      </div>
                      </font>
                      
    <hr style="margin-bottom:-15; margin-top:0px;"/>
                      </span><br />
    </span>
      <span id="lnk_cadastro">
      
                        
      <div  style="position: absolute;"> 
      
        
                        Produto: <a href="#" onclick="MM_showHideLayers('listaProduto','','show','cadastraProd','','hide','atualizaProd','','hide','excluiProd','','hide')"><strong>Visualizar</strong></a> &#124 
                        
                        <a href="#" onclick="MM_showHideLayers('listaProduto','','hide','cadastraProd','','show','atualizaProd','','hide','excluiProd','','hide')"><strong>Novo</strong></a> &#124      
      
          <span  style="position: relative; display:inline-block;">
          
          
          <form action="produtos.php?atualiza=<?php echo $row_RsProdutos['id']; ?>#" name="form8" target="_self" id="form8"  style="position: relative;"> 
                  
           <select name="atualizaprod" id="atualizaprod" onchange="MM_goToURL('parent','produtos.php?atualiza=<?php echo $row_RsProdutos['id']; ?>#');return document.MM_returnValue" onmouseout="MM_jumpMenu('parent',this,0)">
             <?php
    do {  
    ?>
             <option value="?atualiza=<?php echo $row_RsProdutos['id']; ?>#" selected="selected"<?php if (!(strcmp($row_RsProdutos['id'], $row_RsProdutos['id']))) {echo "selected=\"selected\"";} ?>><?php echo $row_RsProdutos['descricao']?></option>
             <?php
    } while ($row_RsProdutos = mysql_fetch_assoc($RsProdutos));
      $rows = mysql_num_rows($RsProdutos);
      if($rows > 0) {
          mysql_data_seek($RsProdutos, 0);
          $row_RsProdutos = mysql_fetch_assoc($RsProdutos);
      }
    ?>
           </select>                 
             
          
          <a href="#" onclick="MM_showHideLayers('listaProduto','','hide','cadastraProd','','hide','atualizaProd','','show','excluiProd','','hide')"><strong >Editar </strong></a>
          </form>
      
      </span>
      &#124 
      <span  style="position: relative; display:inline-block;">
          
          
          <form action="produtos.php?deleta=<?php echo $row_RsProdutos['id']; ?>#" name="form5" target="_self" id="form5"  style="position: relative;"> 
                  
           <select name="excluiprod" id="excluiprod" onchange="MM_goToURL('parent','produtos.php?exclui=<?php echo $row_RsProdutos['id']; ?>#');return document.MM_returnValue" onmouseout="MM_jumpMenu('parent',this,0)">
             <?php
    do {  
    ?>
             <option value="?exclui=<?php echo $row_RsProdutos['id']; ?>#" selected="selected"<?php if (!(strcmp($row_RsProdutos['id'], $row_RsProdutos['id']))) {echo "selected=\"selected\"";} ?>><?php echo $row_RsProdutos['descricao']?></option>
             <?php
    } while ($row_RsProdutos = mysql_fetch_assoc($RsProdutos));
      $rows = mysql_num_rows($RsProdutos);
      if($rows > 0) {
          mysql_data_seek($RsProdutos, 0);
          $row_RsProdutos = mysql_fetch_assoc($RsProdutos);
      }
    ?>
           </select>
          
          
          <a href="#" onclick="MM_showHideLayers('listaProduto','','hide','cadastraProd','','hide','atualizaProd','','hide','excluiProd','','show')"><strong>Excluir </strong></a>                 
             
          </form>
      
      </span>
      </div>
      
      
      
    <div id="listaProduto">
   		<h3>Produtos cadastrados</h3>
                  	<hr style="margin-bottom:-18px;"/>
                    <table width="100%" border="0" align="center" cellpadding="3" cellspacing="3">
                      <tr>
                        <th>C&oacute;d.</th>
                        <th>Descri&ccedil;&atilde;o</th>
                        <th>Quantidade</th>
                        <th>Valor R$</th>
                        <th>Usu&aacute;rio</th>
                        <th>Cadastrado</th>
                        <th>Categoria</th>
                      </tr>
                      <?php do { ?>
                        <tr valign="middle">
                        <a href="#"></a>
                          <td><?php echo $row_RsProdutos['id']; ?></td>
                          <td align="left"><?php echo $row_RsProdutos['descricao']; ?></td>
                          <td><?php echo $row_RsProdutos['quantidade']; ?></td>
                          <td align="right"><?php echo $row_RsProdutos['valorproduto']; ?></td>
                          <td><?php echo $row_RsProdutos['usuario_id']; ?></td>
                          <td><?php echo $row_RsProdutos['data_cadastro']; ?></td>
                          <td style="border-right:#333 1px solid;"><?php echo $row_RsProdutos['categoria_id']; ?></td>
                        </tr>
                        <?php } while ($row_RsProdutos = mysql_fetch_assoc($RsProdutos)); ?>
                    </table>
                    <?php if ($pageNum_RsProdutos > 0) { // Show if not first page ?>
                      <a href="<?php printf("%s?pageNum_RsProdutos=%d%s", $currentPage, 0, $queryString_RsProdutos); ?>" style="text-decoration:none; color:#900;"> &lt;&lt; </a> <a href="<?php printf("%s?pageNum_RsProdutos=%d%s", $currentPage, max(0, $pageNum_RsProdutos - 1), $queryString_RsProdutos); ?>" style="text-decoration:none; color:#900;"> &lt;</a>
                      <?php } // Show if not first page ?>
&#124 <?php echo ($startRow_RsProdutos + 1) ?> a <?php echo min($startRow_RsProdutos + $maxRows_RsProdutos, $totalRows_RsProdutos) ?> &#124
<?php if ($pageNum_RsProdutos < $totalPages_RsProdutos) { // Show if not last page ?>
  <a href="<?php printf("%s?pageNum_RsProdutos=%d%s", $currentPage, min($totalPages_RsProdutos, $pageNum_RsProdutos + 1), $queryString_RsProdutos); ?>" style="text-decoration:none; color:#900;"> &gt; </a> <a href="<?php printf("%s?pageNum_RsProdutos=%d%s", $currentPage, $totalPages_RsProdutos, $queryString_RsProdutos); ?>" style="text-decoration:none; color:#900;"> &gt;&gt; </a>
  <?php } // Show if not last page ?>
    </div>
      <div id="cadastraProd">
            	Cadastrar novo produto<hr style="margin-bottom:2px;"/>
                 <form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
                   <table align="center">
                     <tr valign="baseline">
                       <td nowrap="nowrap" align="right">Descricao:</td>
                       <td><span id="sprycadastraprod">
                       <input name="descricao" type="text" value="<?php echo $row_RsExcluiProd['descricao']; ?>" size="32" maxlength="45" /><br />
            
                                <span class="textfieldRequiredMsg"><small>Campo obrigat&oacute;rio.</small></span>
                                <span class="textfieldMinCharsMsg"><small>M&iacute;nimo de 6 caracteres.</small></span>
                       <span class="textfieldMaxCharsMsg"><small>M&aacute;ximo de 45 caracteres.</small></span></span></td>
                     </tr>
                     <tr valign="baseline">
                       <td nowrap="nowrap" align="right">Quantidade:</td>
                       <td><span id="spryquantprod">
                       <input name="quantidade" type="text" value="" size="32" maxlength="45" /><br />
            
                                <span class="textfieldRequiredMsg"><small>Campo obrigat&oacute;rio.</small></span>
                                <span class="textfieldMinCharsMsg"><small>M&iacute;nimo de 1 caracteres.</small></span>
                       <span class="textfieldMaxCharsMsg"><small>M&aacute;ximo de 45 caracteres.</small></span>
                       <span class="textfieldInvalidFormatMsg"><small>Somente n&uacute;meros inteiros.</small></span></span></td>
                     </tr>
                     <tr valign="baseline">
                       <td nowrap="nowrap" align="right">Valor R&#36;:</td>
                       <td><span id="spryvalorprod">
                       <input name="valorproduto" type="text" value="" />
                       <br />
                       <span class="textfieldRequiredMsg"><small>Campo obrigat&oacute;rio.</small></span> <span class="textfieldInvalidFormatMsg"><small>Somente n&uacute;meros.</small></span></span></td>
                     </tr>
                     <tr valign="baseline">
                       <td nowrap="nowrap" align="right">Categoria:</td>
                       <td><span id="sprycategoriaprod">
                         <select name="categoria_id">
                           <?php 
do {  
?>
                           <option value="<?php echo $row_RsCategoria['id']?>" <?php if (!(strcmp($row_RsCategoria['id'], $row_RsCategoria['id']))) {echo "SELECTED";} ?>><?php echo $row_RsCategoria['descricao']?></option>
                           <?php
} while ($row_RsCategoria = mysql_fetch_assoc($RsCategoria));
?>
                         </select>
                       <span class="selectInvalidMsg"><small>Selecione uma categ	oria.</small></span><span class="selectRequiredMsg"><small>Selecione uma categoria.</small></span></span></td>
                     </tr>
                     <tr> </tr>
                     <tr valign="baseline">
                       <td nowrap="nowrap" align="right">&nbsp;</td>
                       <td><input name="submit" type="submit" id="submit" onclick="MM_showHideLayers('listaProduto','','show')" value="Cadastrar" />
                       <input name="cancela" type="button" id="cancela" onclick="MM_showHideLayers('listaProduto','','show','cadastraProd','','hide')" value="Cancelar" /></td>
                     </tr>
                   </table>
                   <input type="hidden" name="usuario_id" value="<?php echo $_SESSION['MM_loginid']; ?>" />
                   <input type="hidden" name="data_cadastro" value="<?php echo date('Y/m/d H:i:s'); ?>" />
                   <input type="hidden" name="MM_insert" value="form1" />
                 </form>
      </div>  
               
	<div id="atualizaProd">
	            	Atualiza produto (<?php echo $row_RsAtualizaProd['descricao']; ?>)<hr style="margin-bottom:2px;"/>
                    <form action="<?php echo $editFormAction; ?>" method="post" name="form2" id="form2">
                      <table align="center">
                        <tr valign="baseline">
                          <td nowrap="nowrap" align="right">Descricao:</td>
                          <td><span id="spryatualizaprod">
                          <input type="text" name="descricao" value="<?php echo htmlentities($row_RsAtualizaProd['descricao'], ENT_COMPAT, 'utf-8'); ?>" size="32" /><br />
            
                                <span class="textfieldRequiredMsg"><small>Campo obrigat&oacute;rio.</small></span>
                                <span class="textfieldMinCharsMsg"><small>M&iacute;nimo de 6 caracteres.</small></span>
                       <span class="textfieldMaxCharsMsg"><small>M&aacute;ximo de 45 caracteres.</small></span>
                       <span class="textfieldInvalidFormatMsg"><small>Somente n&uacute;meros inteiros.</small></span></span></td>
                        </tr>
                        <tr valign="baseline">
                          <td nowrap="nowrap" align="right">Quantidade:</td>
                          <td><span id="spryatualizaquant">
                          <input type="text" name="quantidade" value="<?php echo htmlentities($row_RsAtualizaProd['quantidade'], ENT_COMPAT, 'utf-8'); ?>" size="32" /><br />
            
                                <span class="textfieldRequiredMsg"><small>Campo obrigat&oacute;rio.</small></span>
                                <span class="textfieldMinCharsMsg"><small>M&iacute;nimo de 6 caracteres.</small></span>
                       <span class="textfieldMaxCharsMsg"><small>M&aacute;ximo de 45 caracteres.</small></span>
                       <span class="textfieldInvalidFormatMsg"><small>Somente n&uacute;meros inteiros.</small></span></span>
                       </tr>
                        <tr valign="baseline">
                          <td nowrap="nowrap" align="right">Valor R$:</td>
                          <td><span id="spryatualizavalor">
                          <input type="text" name="valorproduto" value="<?php echo htmlentities($row_RsAtualizaProd['valorproduto'], ENT_COMPAT, 'utf-8'); ?>" size="32" maxlength="45" /><br />
            
                                <span class="textfieldRequiredMsg"><small>Campo obrigat&oacute;rio.</small></span>
                          <span class="textfieldInvalidFormatMsg"><small>Somente n&uacute;meros.</small></span></span></td>
                        </tr>
                        <tr valign="baseline">
                          <td nowrap="nowrap" align="right">Categoria:</td>
                          <td><span id="spryatualizacateg">
                            <select name="categoria_id">
                              <?php
do {  
?>
                              <option value="<?php echo $row_RsAtualizaCateg['id']?>"<?php if (!(strcmp($row_RsAtualizaCateg['id'], $row_RsAtualizaCateg['id']))) {echo "selected=\"selected\"";} ?>><?php echo $row_RsAtualizaCateg['descricao']?></option>
                              <?php
} while ($row_RsAtualizaCateg = mysql_fetch_assoc($RsAtualizaCateg));
  $rows = mysql_num_rows($RsAtualizaCateg);
  if($rows > 0) {
      mysql_data_seek($RsAtualizaCateg, 0);
	  $row_RsAtualizaCateg = mysql_fetch_assoc($RsAtualizaCateg);
  }
?>
                            </select>
                          <span class="selectInvalidMsg"><small>Selecione uma categ	oria.</small></span><span class="selectRequiredMsg"><small>Selecione uma categoria.</small></span></span></td>
                        </tr>
                        <tr> </tr>
                        <tr valign="baseline">
                          <td nowrap="nowrap" align="right">&nbsp;</td>
                          <td><input name="submit" type="submit" id="submit" onclick="MM_showHideLayers('listaProduto','','show')" value="Atualizar" />
                          <input name="cancela2" type="button" id="cancela2" onclick="MM_showHideLayers('listaProduto','','show','atualizaProd','','hide')" value="Cancelar" /></td>
                        </tr>
                      </table>
                      
              			<input type="hidden" name="usuario_id" value="<?php echo htmlentities($_SESSION['MM_loginid']); ?>" />
                      <input type="hidden" name="data_cadastro" value="<?php echo htmlentities($row_RsAtualizaProd['data_cadastro'], ENT_COMPAT, 'utf-8'); ?>" />
                      <input type="hidden" name="MM_update" value="form2" />
                      <input type="hidden" name="id" value="<?php echo $row_RsAtualizaProd['id']; ?>" />
                   <input type="hidden" name="data_cadastro" value="<?php echo date('Y/m/d H:i:s'); ?>" />
                   <input name="select" type="hidden" id="select" value="produtos.php?atualiza=<?php echo $row_RsProdutos['id']; ?>" />
        </form>
    </div>
    
	<div id="excluiProd">
    	Excluir produto (<?php echo $row_RsExcluiProd['descricao']; ?>)
<hr style="margin-bottom:2px;"/>
		<form action="produtos.php?delete=<?php echo $row_RsExcluiProd['id']; ?>" method="post" id="form3">
		  <input name="id" type="hidden" id="id" value="<?php echo $row_RsExcluiProd['id']; ?>" />
          Produto:
        	<input name="descricao2" type="text" id="descricao" value="<?php echo $row_RsExcluiProd['descricao']; ?>" readonly="readonly" />
       	  <input name="delete" type="submit" onclick="MM_showHideLayers('listaProduto','','show')" value="Excluir" />
            <input name="cancela" type="button" onclick="MM_showHideLayers('listaProduto','','show','excluiProd','','hide')" value="Cancelar" />
        </form>

    </div>
    	           
                 
  	</div>
  </div>
    <div id="rodape" style="width:100%; height:auto; padding:5px; position: fixed; background-color:#000; color:#fff; bottom:0px; text-align:center;">
          André Augusto Aguiar Gomes,
    cursando Gest&atilde;o de Tecnologia da Informa&ccedil;&atilde;o.
    
    31 3327-5397 &#124 31 99277-0410 &#124 andreaguiar.g@gmail.com
    </div>

</div>
<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprycadastraprod", "none", {minChars:6, maxChars:45});
var sprytextfield2 = new Spry.Widget.ValidationTextField("spryquantprod", "integer", {minChars:1, maxChars:45});
var sprytextfield3 = new Spry.Widget.ValidationTextField("spryvalorprod", "currency", {format:"dot_comma", useCharacterMasking:true});
var spryselect1 = new Spry.Widget.ValidationSelect("sprycategoriaprod", {invalidValue:"0"});
var sprytextfield4 = new Spry.Widget.ValidationTextField("spryatualizaprod", "none", {minChars:6, maxChars:45});
var sprytextfield5 = new Spry.Widget.ValidationTextField("spryatualizaquant", "integer", {minChars:1, maxChars:45});
var sprytextfield6 = new Spry.Widget.ValidationTextField("spryatualizavalor", "currency", {format:"dot_comma", useCharacterMasking:true});
var spryselect2 = new Spry.Widget.ValidationSelect("spryatualizacateg");

</script>
</body>
</html>
<?php
mysql_free_result($RsProdutos);

mysql_free_result($RsCategoria);

mysql_free_result($RsAtualizaProd);

mysql_free_result($RsAtualizaCateg);

mysql_free_result($RsExcluiProd);
?>
